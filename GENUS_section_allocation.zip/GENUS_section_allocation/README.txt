1) create your section allocation csv file by:
    1.1) converting your excel sheet to a csv file
    1.2) following the format shown in template.csv OR 21_22s1_example.csv. (Note Column 3 onwards can have any number of preferences)
        1.2.1) Column1: name, Column2: previousSection, Column3: 1st Preference, Column4: 2nd Preference, Column5: 3rd Preference
            *column headers doesn't actually matter, allocator will ignore first row
2) run start.bat
3) ???
4) stonks